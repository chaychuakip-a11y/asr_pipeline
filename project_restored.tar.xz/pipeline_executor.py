"""
ASR Pipeline Executor

ASR 自动化流水线执行器，支持以下功能：
- Phase 1: 资源打包与 G2P (发音预测)
- Phase 2: 增量测试集生成
- Phase 3: 模型评估 (TODO)

Usage:
    python pipeline_executor.py -g config/global_config.yaml -j config/job.yaml
"""

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime

import pandas as pd
import yaml


# =============================================================================
# 全局常量定义 (Global Constants)
# =============================================================================

LANG_ABBR_MAP = {
    "0": "en",    # english
    "1": "fr",    # french
    "2": "es",    # spanish
    "3": "de",    # german
    "4": "it",    # italy
    "5": "ar",    # arabic
    "6": "tl",    # filipino
    "7": "hi",    # hindi
    "8": "ms",    # malaysia
    "9": "pl",    # poland
    "10": "th",   # thai
    "11": "tr",   # turkey
    "12": "yue",  # yueyu
    "13": "ru",   # russian
    "14": "ja",   # japan
    "15": "pt",   # portugal
    "16": "id",   # indonesia
    "17": "fa"    # persian
}

SCHEME_MAP = {
    "0": "ubctc",
    "1": "rnntCTC",
    "2": "rnntED",
    "3": "cloud"
}

RES_DIR_MAP = {
    "0": "ubctc_duan",
    "1": "rnnt_ctc_duan",
    "2": "rnnt_ed_duan",
    "3": "yun"
}


# =============================================================================
# 工具函数 (Utility Functions)
# =============================================================================

def load_language_map(file_path: str) -> dict:
    """加载语言映射文件。"""
    if not os.path.exists(file_path):
        print(f"Error: Language map file not found at {file_path}", file=sys.stderr)
        sys.exit(1)

    lang_map = {}
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line or ':' not in line:
                continue
            k, v = line.split(':', 1)
            lang_map[k.strip()] = v.strip().lower()
    return lang_map


def run_subprocess(cmd: list, cwd: str, log_file: str) -> bool:
    """执行子进程命令并记录日志。"""
    try:
        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        with open(log_file, 'a') as f:
            f.write(f"\n[{datetime.now().strftime('%H:%M:%S')}] CMD: {' '.join(cmd)}\n")
            f.flush()
            process = subprocess.Popen(cmd, cwd=cwd, stdout=f, stderr=subprocess.STDOUT)
            process.wait()
            return process.returncode == 0
    except Exception as e:
        with open(log_file, 'a') as f:
            f.write(f"\n[FATAL ERROR] {str(e)}\n")
        return False


def resolve_and_bind_paths(global_cfg: dict, base_path: str) -> dict:
    """解析并绑定配置中的相对路径为绝对路径。"""
    py_exec = global_cfg.get('python_exec')
    if not py_exec:
        global_cfg['python_exec'] = sys.executable
    elif not os.path.isabs(py_exec):
        global_cfg['python_exec'] = os.path.abspath(os.path.join(base_path, py_exec))

    local_keys = [
        'g2p_root_dir', 'tools_dir', 'merge_dict_script',
        'adapter_script', 'test_script'
    ]
    for key in local_keys:
        val = global_cfg.get(key)
        if val and not os.path.isabs(val):
            global_cfg[key] = os.path.abspath(os.path.join(base_path, val))

    return global_cfg


def safe_copy_oov_content(src_path: str, dst_path: str, log_file: str) -> bool:
    """安全拷贝 OOV 文件到 G2P 输入端（严格保留原始二进制编码与换行符）。"""
    try:
        shutil.copy2(src_path, dst_path)
        return True
    except Exception as e:
        with open(log_file, 'a', encoding='utf-8') as f:
            f.write(f"\n[ERROR] Failed to copy OOV content from {src_path} to {dst_path}: {str(e)}\n")
        return False


# =============================================================================
# 增量追踪器 (Delta Tracker)
# =============================================================================

class DeltaTracker:
    """基于语义哈希的增量追踪器，用于避免重复处理未变更的文件。"""

    def __init__(self, manifest_path: str):
        self.manifest_path = manifest_path
        self.history = self._load_manifest()

    def _load_manifest(self) -> dict:
        """加载历史记录文件。"""
        if os.path.exists(self.manifest_path):
            with open(self.manifest_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}

    def get_semantic_hash(self, file_path: str) -> str:
        """
        计算文件的语义哈希值。

        支持业务模板与普通语料降级：
        - 识别 'sent'/'shuofa' 列或 '<>' 标签页
        - 降级处理：无特殊页时读取第一列或 'text' 列
        - 失败时回退到 MD5 文件哈希
        """
        try:
            xl = pd.ExcelFile(file_path)
            content_list = []
            has_special_sheet = False

            for sheet in xl.sheet_names:
                sheet_lower = sheet.lower()
                if 'sent' in sheet_lower or 'shuofa' in sheet_lower:
                    has_special_sheet = True
                    df = pd.read_excel(xl, sheet_name=sheet, header=None)
                    vals = df.values.flatten()
                    content_list.extend([
                        str(x).strip() for x in vals
                        if pd.notna(x) and str(x).strip()
                    ])
                elif '<>' in sheet:
                    has_special_sheet = True
                    df = pd.read_excel(xl, sheet_name=sheet)
                    for col in df.columns:
                        col_name = str(col).strip()
                        if col_name.startswith('<') and col_name.endswith('>'):
                            vals = df[col].dropna().astype(str).str.strip().tolist()
                            content_list.extend([col_name] + vals)

            if not has_special_sheet:
                df = pd.read_excel(xl, sheet_name=0)
                if 'text' in df.columns:
                    vals = df['text'].dropna().astype(str).str.strip().tolist()
                else:
                    vals = df.iloc[:, 0].dropna().astype(str).str.strip().tolist()
                content_list.extend(vals)

            if not content_list:
                raise ValueError("No valid text content found.")

            content_str = "|".join(content_list)
            return hashlib.md5(content_str.encode('utf-8')).hexdigest()

        except Exception:
            # 降级：使用文件 MD5
            with open(file_path, "rb") as f:
                return hashlib.md5(f.read()).hexdigest()

    def is_modified(self, file_path: str) -> bool:
        """检查文件是否已修改。"""
        current_hash = self.get_semantic_hash(file_path)
        file_key = os.path.basename(file_path)
        return self.history.get(file_key) != current_hash

    def mark_as_processed(self, file_path: str):
        """标记文件为已处理状态。"""
        current_hash = self.get_semantic_hash(file_path)
        file_key = os.path.basename(file_path)
        self.history[file_key] = current_hash
        os.makedirs(os.path.dirname(self.manifest_path), exist_ok=True)
        with open(self.manifest_path, 'w', encoding='utf-8') as f:
            json.dump(self.history, f, indent=4, ensure_ascii=False)


# =============================================================================
# Phase 1: 资源打包与 G2P
# =============================================================================

def build_base_command(task: dict, python_exec: str, train_script: str,
                       asrmlg_exp_dir: str) -> list:
    """构建基础命令行参数。"""
    base_cmd = [
        python_exec if train_script.endswith('.py') else "bash",
        train_script
    ]

    if 'l' in task:
        base_cmd.extend(["-l", str(task['l'])])
    if 'G' in task:
        base_cmd.extend(["-G", str(task['G'])])
    if 'is_yun' in task:
        base_cmd.extend(["--is_yun", str(task['is_yun'])])
    if 'excel_corpus_path' in task:
        corpus_abs_path = os.path.join(asrmlg_exp_dir, task['excel_corpus_path'])
        base_cmd.extend(["--excel_corpus_path", corpus_abs_path])
    if 'msg' in task:
        base_cmd.extend(["--msg", str(task['msg'])])
    if task.get('predict_phone_for_new'):
        base_cmd.append("--predict_phone_for_new")

    return base_cmd


def step1_extract_oov(base_cmd: list, task_out_path: str, msg: str,
                      asrmlg_exp_dir: str, log_file: str) -> bool:
    """Phase 1 Step 1: 提取 OOV 词汇。"""
    task_out_path_temp = task_out_path + "_temp"
    cmd = base_cmd + ["--only_corpus_process", "--output", task_out_path_temp]

    print(f"[{datetime.now().strftime('%H:%M:%S')}] STARTING: Phase1_Step1 (Extract OOV) for {msg}")
    return run_subprocess(cmd, asrmlg_exp_dir, log_file)


def step2_g2p_predict(task: dict, global_cfg: dict, msg: str, task_out_path: str,
                      log_file: str) -> bool:
    """Phase 1 Step 2: G2P 发音预测。"""
    task_out_path_temp = task_out_path + "_temp"
    oov_file_path = os.path.join(
        task_out_path_temp, "custom_corpus_process", "dict_dir", "aaa_oov_base_dict"
    )

    # 数据驱动检查
    if not os.path.exists(oov_file_path) or os.path.getsize(oov_file_path) == 0:
        with open(log_file, 'a', encoding='utf-8') as f:
            f.write(f"\n[INFO] OOV file empty or missing at {oov_file_path}. Skipping G2P prediction.\n")
        return True

    lang_id = str(task.get('l', ''))
    lang_abbr = LANG_ABBR_MAP.get(lang_id) or task.get('language', msg)
    g2p_root = global_cfg.get('g2p_root_dir')
    g2p_lang_dir = os.path.join(g2p_root, str(lang_abbr), "g2p_models")
    g2p_input_txt = os.path.join(g2p_lang_dir, "input.txt")

    print(f"[{datetime.now().strftime('%H:%M:%S')}] {g2p_input_txt}")

    if not os.path.isdir(g2p_lang_dir):
        warning_msg = f"\n[WARNING] G2P directory not found: {g2p_lang_dir}. Skipping G2P.\n"
        try:
            with open(log_file, 'a', encoding='utf-16le') as f:
                f.write(warning_msg)
        except Exception:
            with open(log_file, 'a', encoding='utf-8') as f:
                f.write(warning_msg)
        return True

    print(f"[{datetime.now().strftime('%H:%M:%S')}] STARTING: Phase1_Step2 (G2P Predict OOV) for {msg}")

    try:
        # 读取 UTF-8 源文件
        with open(oov_file_path, 'r', encoding='utf-8', errors='ignore') as f_in:
            content = f_in.read()
        # 写入 UCS-2 LE BOM (Windows CRLF)
        with open(g2p_input_txt, 'w', encoding='utf-16', newline='\r\n') as f_out:
            f_out.write(content)
    except Exception as e:
        shutil.copy2(oov_file_path, g2p_input_txt)
        with open(log_file, 'a', encoding='utf-8') as f_log:
            f_log.write(f"[ERROR] Transcoding to UCS-2 LE BOM failed: {str(e)}\n")

    g2p_script_cmd = ["bash", "run.sh"]
    return run_subprocess(g2p_script_cmd, g2p_lang_dir, log_file)


def step3_merge_dict(task: dict, global_cfg: dict, msg: str, log_file: str) -> bool:
    """Phase 1 Step 3: 合并预测发音到主词典。"""
    merge_script = global_cfg.get('merge_dict_script')
    res_base_dir = os.path.join(global_cfg.get('asrmlg_exp_dir'), global_cfg.get('res_dir_name'))

    if not (merge_script and os.path.exists(merge_script) and res_base_dir):
        with open(log_file, 'a', encoding='utf-8') as f:
            f.write(f"\n[WARNING] merge_dict_script or res_root_dir missing. Skipping Merge.\n")
        return True

    print(f"[{datetime.now().strftime('%H:%M:%S')}] STARTING: Phase1_Step3 (Merge OOV Dict) for {msg}")

    python_exec = global_cfg.get('python_exec', 'python')
    vcs_script_path = os.path.join(global_cfg.get('tools_dir', './'), 'lexicon_vcs.py')

    lang_id = str(task.get('l', 0))
    lang_map = global_cfg.get('parsed_language_map', {})
    lang_name = lang_map.get(lang_id, "")
    lang_abbr = LANG_ABBR_MAP.get(lang_id)

    is_yun_val = str(task.get('is_yun', '0'))
    res_dir_name = RES_DIR_MAP.get(is_yun_val, "unknown")

    target_res_dir = os.path.join(res_base_dir, f"{lang_name}_res", res_dir_name)
    target_dict_path = os.path.join(target_res_dir, "new_dict")
    phone_syms_path = os.path.join(target_res_dir, "phones.syms")
    g2p_output_dict = os.path.join(
        global_cfg.get('g2p_root_dir', ''), lang_abbr, "g2p_models", "output.dict"
    )

    print(f"[{datetime.now().strftime('%H:%M:%S')}] merging {target_dict_path}")

    if not os.path.exists(g2p_output_dict):
        with open(log_file, 'a', encoding='utf-8') as f:
            f.write(f"\n[ERROR] g2p_output_dict missing at {g2p_output_dict}. Aborting Merge.\n")
        return False

    # Pre-merge
    if os.path.exists(vcs_script_path):
        run_subprocess([python_exec, vcs_script_path, "-i", target_dict_path, "pre_merge"],
                       global_cfg.get('asrmlg_exp_dir'), log_file)

    # 合并
    merge_cmd = [
        python_exec, merge_script,
        "-i", g2p_output_dict,
        "-o", target_dict_path,
        "-p", phone_syms_path
    ]
    if task.get('predict_phone_for_new'):
        merge_cmd.append("--predict_phone_for_new")

    merge_success = run_subprocess(merge_cmd, global_cfg.get('asrmlg_exp_dir'), log_file)

    # Post-merge
    if merge_success and os.path.exists(vcs_script_path):
        run_subprocess([
            python_exec, vcs_script_path,
            "-i", target_dict_path,
            "post_merge",
            "-m", task.get('msg', ''),
            "-l", lang_id,
            "--max_versions", str(global_cfg.get('max_versions', 10))
        ], global_cfg.get('asrmlg_exp_dir'), log_file)

    return True


def step4_full_build(base_cmd: list, task_out_path: str, msg: str,
                     patch_type: str, asrmlg_exp_dir: str, log_file: str) -> bool:
    """Phase 1 Step 4: 全量资源打包。"""
    # 清理临时目录
    task_out_path_temp = task_out_path + "_temp"
    print(f"[{datetime.now().strftime('%H:%M:%S')}] CLEANING: temp dir")
    try:
        shutil.rmtree(task_out_path_temp)
        print(f"Successfully deleted: {task_out_path_temp}")
    except OSError as e:
        print(f"Error: {task_out_path_temp} : {e.strerror}")

    print(f"[{datetime.now().strftime('%H:%M:%S')}] STARTING: Phase1_Step4 (Full Resource Build) for {msg}")

    base_cmd = base_cmd + ["--output", task_out_path]
    try:
        idx = base_cmd.index("--msg")
        base_cmd[idx + 1] = f"{msg}_{patch_type}"
    except (ValueError, IndexError):
        base_cmd.extend(["--msg", f"{msg}_{patch_type}"])

    return run_subprocess(base_cmd, asrmlg_exp_dir, log_file)


def run_phase1_pipeline(task: dict, global_cfg: dict, asrmlg_exp_dir: str,
                        python_exec: str, train_script: str, log_file: str) -> bool:
    """
    执行 Phase 1 完整流水线。

    Steps:
        1. 提取 OOV
        2. G2P 预测 (可选)
        3. 合并词典 (可选)
        4. 全量资源打包
    """
    msg = str(task.get('msg'))
    lang_id = str(task.get('l', ''))
    base_out_dir = global_cfg.get('output_dir')
    resolved_msg = str(task.get('msg', '')).strip()

    lang_map = global_cfg.get('parsed_language_map', {})
    lang_name = lang_map.get(lang_id, f"lang_{lang_id}")
    model_type = SCHEME_MAP.get(task.get('is_yun', 0), 'unknown')
    task_out_path = os.path.join(
        base_out_dir, lang_name, resolved_msg,
        f"{model_type}_{datetime.now().strftime('%Y%m%d')}"
    )

    # 构建基础命令
    base_cmd = build_base_command(task, python_exec, train_script, asrmlg_exp_dir)

    # Step 1: 提取 OOV
    if not step1_extract_oov(base_cmd, task_out_path, msg, asrmlg_exp_dir, log_file):
        return False

    # Step 2: G2P 预测
    if task.get('enable_g2p'):
        if not step2_g2p_predict(task, global_cfg, msg, task_out_path, log_file):
            return False

    # Step 3: 合并词典
    if task.get('enable_merge_dict'):
        step3_merge_dict(task, global_cfg, msg, log_file)

    # Step 4: 全量资源打包
    is_yun_val = str(task.get('is_yun', '0'))
    patch_type = SCHEME_MAP.get(is_yun_val, "unknown")
    return step4_full_build(base_cmd, task_out_path, msg, patch_type, asrmlg_exp_dir, log_file)


def execute_phase1(tasks: list, global_cfg: dict, executor: ProcessPoolExecutor):
    """执行 Phase 1 调度。"""
    print("\n=== Pipeline Phase 1: Resource Build & G2P (3-Step Mode) ===")

    python_exec = global_cfg.get('python_exec')
    asrmlg_exp_dir = global_cfg.get('asrmlg_exp_dir')
    train_script = os.path.join(
        asrmlg_exp_dir, global_cfg.get('train_script', 'corpus_process_package.py')
    )

    futures = {}
    for task in tasks:
        if not task.get('enable_g2p') and not task.get('enable_merge_dict'):
            continue

        lang_id = str(task.get('l', 0))
        lang_map = global_cfg.get('parsed_language_map', {})
        lang_name = lang_map.get(lang_id, f"lang_{lang_id}")
        msg = str(task.get('msg'))

        log_dir = os.path.join(global_cfg.get('output_dir'), "logs", lang_name, msg)
        log_file = os.path.join(log_dir, f"phase1_build_{datetime.now().strftime('%Y%m%d')}.log")

        futures[msg] = executor.submit(
            run_phase1_pipeline, task, global_cfg, asrmlg_exp_dir,
            python_exec, train_script, log_file
        )

    for msg, future in futures.items():
        status = "SUCCESS" if future.result() else "FAILED"
        print(f"[{datetime.now().strftime('%H:%M:%S')}] {status}: Phase1_{msg}")


# =============================================================================
# Phase 2: 测试集生成
# =============================================================================

def process_single_excel(file_path: str, task: dict, global_cfg: dict,
                         lang: str, log_file: str) -> bool:
    """处理单个 Excel 文件的完整抽取。"""
    python_exec = global_cfg.get('python_exec')
    adapter_script = global_cfg.get('adapter_script')
    output_base_dir = global_cfg.get('output_dir')
    asrmlg_exp_dir = global_cfg.get('asrmlg_exp_dir')
    test_script = global_cfg.get('test_script')

    if not test_script:
        test_script = os.path.join(global_cfg.get('tools_dir', 'tools'), 'make_test_set.py')

    excel_basename = os.path.splitext(os.path.basename(file_path))[0]
    hash_val = hashlib.md5(file_path.encode('utf-8')).hexdigest()[:8]
    txt_temp_path = os.path.join(output_base_dir, "test_sets", "temp", f"{hash_val}.txt")

    # Step 1: Adapter 抽取
    adapter_cmd = [
        python_exec, adapter_script,
        "-i", file_path, "-o", txt_temp_path, "-n", "1000"
    ]
    if not run_subprocess(adapter_cmd, global_cfg.get('tools_dir'), log_file):
        return False

    # Step 2: Compiler 生成测试集
    testset_output_dir = os.path.join(output_base_dir, "test_sets", lang, excel_basename)
    compiler_cmd = [
        python_exec, test_script,
        "-e", asrmlg_exp_dir,
        "-l", str(task.get('l')),
        "-i", txt_temp_path,
        "--output", testset_output_dir,
        "--tts"
    ]
    if task.get('input_wav'):
        compiler_cmd.extend(["-iw", str(task.get('input_wav'))])

    if not run_subprocess(compiler_cmd, asrmlg_exp_dir, log_file):
        return False

    # 清理临时目录
    try:
        shutil.rmtree(testset_output_dir)
        print(f"Successfully deleted: {testset_output_dir}")
    except OSError as e:
        print(f"Error: {testset_output_dir} : {e.strerror}")

    return True


def execute_testset_phase(tasks: list, global_cfg: dict, executor: ProcessPoolExecutor):
    """执行 Phase 2 测试集生成。"""
    print("\n=== Pipeline Phase 2: Incremental Test Set Generation ===")

    output_base_dir = global_cfg.get('output_dir')
    asrmlg_exp_dir = global_cfg.get('asrmlg_exp_dir')

    for task in tasks:
        if not task.get('enable_testset'):
            continue

        msg = str(task.get('msg'))
        lang_id = str(task.get('l', 0))
        lang_map = global_cfg.get('parsed_language_map', {})
        lang_name = lang_map.get(lang_id, f"lang_{lang_id}")
        corpus_dir = os.path.join(asrmlg_exp_dir, task.get('excel_corpus_path', ''))

        if not os.path.exists(corpus_dir):
            print(f"[Warning] Corpus dir not found: {corpus_dir}")
            continue

        manifest_path = os.path.join(
            output_base_dir, "test_sets", f"{lang_name}_{msg}_testset_manifest.json"
        )
        tracker = DeltaTracker(manifest_path)
        log_dir = os.path.join(output_base_dir, "logs", lang_name, msg)

        excel_files = [
            os.path.join(corpus_dir, f) for f in os.listdir(corpus_dir)
            if f.endswith('.xlsx') and not f.startswith('~')
        ]

        for file_path in excel_files:
            if not tracker.is_modified(file_path):
                print(f"[Skip] No semantic changes detected: {os.path.basename(file_path)}")
                continue

            excel_basename = os.path.splitext(os.path.basename(file_path))[0]
            log_file = os.path.join(log_dir, f"testset_{excel_basename}_{datetime.now().strftime('%Y%m%d')}.log")

            print(f"[{datetime.now().strftime('%H:%M:%S')}] PROCESSING: {excel_basename}...")

            success = executor.submit(
                process_single_excel, file_path, task, global_cfg, lang_name, log_file
            ).result()

            if success:
                tracker.mark_as_processed(file_path)
                print(f"[{datetime.now().strftime('%H:%M:%S')}] SUCCESS: {excel_basename}")
            else:
                print(f"[{datetime.now().strftime('%H:%M:%S')}] FAILED: {excel_basename}. Please check logs.")


# =============================================================================
# Phase 3: 模型评估
# =============================================================================

def execute_eval_phase(tasks: list, global_cfg: dict, executor: ProcessPoolExecutor):
    """执行 Phase 3 模型评估 (TODO)。"""
    print("\n=== Pipeline Phase 3: Baseline Evaluation ===")

    python_exec = global_cfg.get('python_exec')
    asrmlg_exp_dir = global_cfg.get('asrmlg_exp_dir')
    eval_script = os.path.join(
        asrmlg_exp_dir, global_cfg.get('eval_script', 'evaluate.py')
    )

    futures = {}
    for task in tasks:
        if not task.get('enable_eval'):
            continue

        msg = str(task.get('msg'))
        log_dir = os.path.join(global_cfg.get('output_dir'), "logs", msg)
        log_file = os.path.join(log_dir, f"phase3_eval_{datetime.now().strftime('%Y%m%d')}.log")

        cmd = [python_exec, eval_script, "--msg", msg]

        print(f"[{datetime.now().strftime('%H:%M:%S')}] STARTING: Eval_{msg}")
        futures[msg] = executor.submit(run_subprocess, cmd, asrmlg_exp_dir, log_file)

    for msg, future in futures.items():
        status = "SUCCESS" if future.result() else "FAILED"
        print(f"[{datetime.now().strftime('%H:%M:%S')}] {status}: Eval_{msg}")


# =============================================================================
# 主入口 (Main Entry)
# =============================================================================

def main():
    """主函数入口。"""
    parser = argparse.ArgumentParser(description="ASR Pipeline Executor")
    parser.add_argument('-g', '--global_config', required=True, help='Path to global_config.yaml')
    parser.add_argument('-j', '--job', required=True, help='Path to job.yaml')
    args = parser.parse_args()

    base_path = os.path.dirname(os.path.abspath(__file__))

    # 加载配置
    with open(args.global_config, 'r', encoding='utf-8') as f:
        global_cfg = yaml.safe_load(f)
    with open(args.job, 'r', encoding='utf-8') as f:
        job_cfg = yaml.safe_load(f)

    global_cfg = resolve_and_bind_paths(global_cfg, base_path)
    tasks = job_cfg.get('tasks', [])

    lang_map_path = global_cfg.get('language_map_name')
    global_cfg['parsed_language_map'] = load_language_map(
        os.path.join(global_cfg.get('asrmlg_exp_dir'), lang_map_path)
    )

    # 执行流水线
    with ProcessPoolExecutor(max_workers=4) as executor:
        execute_phase1(tasks, global_cfg, executor)
        execute_testset_phase(tasks, global_cfg, executor)
        execute_eval_phase(tasks, global_cfg, executor)


if __name__ == "__main__":
    main()
